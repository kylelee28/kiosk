"use strict"

const fs = require("fs").promises
const { json } = require("express");
const moment = require('moment');

class UserStorage {

    static #info = {
        "id": [],
        "seats": [],
        "loginTime": [],
        "phone": [],
        "logoutTIme": [],
        "initialEndtime": [],
        "remainedTime": [],
        "product": [],
        "time": [],
        "price": [],
        "validity": []
    }

    static #coveredInfo = {
        "id": "N",
        "psword": "N",
        "product": "N",
    }

    static #selectInfo = {
        "id": "N",
        "seats": "N",
        "remainedTime": "N",
        "product ": "N",
        "phone": "N",
    }

    static #getUserInfo(data, id) {
        const users = JSON.parse(data)
        const idx = users.id.indexOf(id)
        const usersKeys = Object.keys(users)
        const userInfo = usersKeys.reduce((newUser, info) => {
            newUser[info] = users[info][idx]
            return newUser
        }, {})
        return userInfo
    }

    static #getlogoutInfo(data, id) {
        const users = JSON.parse(data)
        const idx = users.id.indexOf(id)
        const usersKeys = Object.keys(users)
        const userInfo = usersKeys.reduce((newUser, info) => {
            newUser[info] = users[info][idx]
            return newUser
        }, {})
        return userInfo
    }

    static #getUsers(data, isAll) {
        const users = JSON.parse(data)
        if (isAll) return users
        const newUsers = fields.reduce((newUsers, field) => {
            if (users.hasOwnProperty(field)) {
                newUsers[field] = users[field]
            }
            return newUsers
        }, {})
        return newUsers
    }

    static #getproductData(data, isAll) {
        const users = JSON.parse(data)
        if (isAll) return users
        const newUsers = fields.reduce((newUsers, field) => {
            if (users.hasOwnProperty(field)) {
                newUsers[field] = users[field]
            }
            return newUsers
        }, {})
        return newUsers
    }

    static getArrayInfo() {
        return this.#info
    }

    static getUsers(isAll) {
        return fs
            .readFile("./src/databases/users.json")
            .then((data) => {
                return this.#getUsers(data, isAll)
            })
            .catch(console.error)
    }

    static getUserInfo(id) {
        return fs
            .readFile("./src/databases/users.json")
            .then((data) => {
                return this.#getUserInfo(data, id)
            })
            .catch(console.error)
    }


    static async save(userInfo) {
        const users = await this.getUsers(true)
        if (users.id.includes(userInfo.id)) {
            console.log(userInfo.id)
            throw "이미 존재하는 아이디입니다."
        }
        users.id.push(userInfo.id)
        users.phone.push(userInfo.phone)
        users.name.push(userInfo.name)
        users.psword.push(userInfo.psword)

        fs.writeFile("./src/databases/users.json", JSON.stringify(users))
        return { success: true }
    }


    static async setSave(body) {
        const coveredInfo = JSON.parse(await fs.readFile('./src/databases/user.json'))
        const idKey = coveredInfo.id
        const productInfo = coveredInfo.product


        const allUserInfo = JSON.parse(await fs.readFile('./src/databases/alluser.json'))
        const typeInfo = JSON.parse(await fs.readFile('./src/databases/seatsType.json'))
        const subProduct = productInfo.substring(0, 3)

        /**변수.변수는 말이 안된다. 이거 처음봤네.. 변수[변수] */
        const seatsType = typeInfo[subProduct]
        if (seatsType.includes(body.seats)) {
            allUserInfo.forEach((allUserInfos, index, arr) => {
                if (allUserInfos.id === idKey) {
                    const idx = arr[index].product.indexOf(productInfo)
                    arr[index].seats[idx] = body.seats
                }
            }
            )
            await fs.writeFile(('./src/databases/alluser.json'), JSON.stringify(allUserInfo));
            return { success: true, msg: "좌석 저장 완료!" }
        } else {
            return { success: false, msg: "해당 이용권으로는 선택할 수 없는 좌석입니다." }
        }
    }


    static getlogoutInfo(id) {
        return fs.readFile("./src/databases/users.json")
            .then((data) => {
                return this.#getlogoutInfo(data, id)
            })
            .catch(console.error)
    }

    /**이당시에 코딩을 잘못했다. 처음부터 remainedtTIme이 가장 긴걸 가져오는게 아니라
     * 내가 처음부터 그것을 선택하고 해당 product의 idx를 가져와서 logintime[idx]의 
     * nowtime을 잡는 방향으로 코딩을 했어야 한다. 
     */

    /**로그인했을 떄 로그인 타임을 잡는게 아니라 로그인 한 뒤에 타입 설정 후 해당 idx에 넣는다. */
    static async loginTime() {
        const nowTime = moment();
        const covered = JSON.parse(await fs.readFile('./src/databases/user.json'))
        const idKey = covered.id
        const productKey = covered.product
        const allUserInfo = JSON.parse(await fs.readFile('./src/databases/alluser.json'))

        allUserInfo.forEach((allUserInfos, index, arr) => {
            if (allUserInfos.id === idKey) {
                const productArr = arr[index].product
                const idx = productArr.findIndex(productArrs => productArrs === productKey);
                arr[index].loginTime[idx] = nowTime
            }
        }
        )
        await fs.writeFile(('./src/databases/alluser.json'), JSON.stringify(allUserInfo))

    }


    /**남은시간이 가장 큰 상품권을 보여준다. 
     * 여기서부터 시간 차감을 들어가면 안되지. 좌석 선택 후 시간 차감이 들어가야 되는데
     */
    static async coveredProduct(body) {
        var coveredInfo = this.#coveredInfo
        coveredInfo.id = body.loginId
        coveredInfo.psword = body.loginPsword

        const allUserInfo = JSON.parse(await fs.readFile('./src/databases/alluser.json'))

        allUserInfo.forEach((allUserInfos, index, arr) => {
            if (allUserInfos.id === body.loginId) {
                const remained = arr[index].remainedTime
                const idx = remained.findIndex(remaineds => remaineds === Math.max.apply(null, remained));
                coveredInfo.product = arr[index].product[idx]
            }
        })

        await fs.writeFile(('./src/databases/user.json'), JSON.stringify(coveredInfo))
    }

    /**퇴실 처리를 하는 경우에는 초깃값이 없는데요 */
    static async logoutTime(body) {
        const nowTime = moment();
        const allUserInfo = JSON.parse(await fs.readFile('./src/databases/alluser.json'))


        /**includes를 쓸때랑 === 쓸때 구분 잘하자. */
        allUserInfo.forEach((allUserInfos, index, arr) => {
            if (allUserInfos.seats.includes(body.checkSeats)) {
                const seatsArr = arr[index].seats
                const idx = seatsArr.findIndex(seatsArrs => seatsArrs === body.checkSeats);

                arr[index].logoutTime[idx] = nowTime
                /**useTime을 놔둘 이유가 있나? */
                var remained = arr[index].remainedTime[idx] - (moment().diff(arr[index].loginTime[idx]))
                arr[index].useTime[idx] = moment().diff(moment(arr[index].loginTime[idx]))
                /**loginTIme을 "N"로 만들어줘야한다. */
                arr[index].remainedTime[idx] = remained
                arr[index].loginTime[idx] = "N"
            }
        })

        await fs.writeFile(('./src/databases/alluser.json'), JSON.stringify(allUserInfo))
        return { success: true, msg: "퇴실 성공" }
    }



    static async listSave(body) {

        let dataArray = []

        try {
            const data = JSON.parse(await fs.readFile("./src/databases/productDisplay.json"))
            const fullArray = {
                product: body.addProduct,
                price: body.addPrice,
                time: body.addTime,
                validity: body.addValidity
            }

            data.push({ ...fullArray })//이거 왜씀??

            await fs.writeFile("./src/databases/productDisplay.json", JSON.stringify(data))
        } catch (err) {
            await fs.writeFile("./src/databases/productDisplay.json", JSON.stringify(dataArray))
            dataArray.push(
                {
                    product: body.addProduct,
                    price: body.addPrice,
                    time: body.addTime,
                    validity: body.addValidity
                }
            )
            await fs.writeFile("./src/databases/productDisplay.json", JSON.stringify(dataArray))
        }

        return { success: true, msg: "저장 성공!" }
    }

    static getproductData(id) {
        return fs
            .readFile("./src/databases/productDisplay.json")
            .then((data) => {
                return this.#getproductData(data, id)
            })
            .catch(console.error)
    }

    static async getKiocedata(body) {

        var regex = /[^0-9]/g;
        var regexTime = body.time.replace(regex, "N");
        var regexValidity = body.validity.replace(regex, "N");


        function addNumber(time) {
            var bodyPlus = "N"

            if (time.includes('시간')) {
                bodyPlus = moment().add(time, "hours")
            } else {
                bodyPlus = moment().add(time, "days")
            }
            return bodyPlus
        }



        const coveredInfo = JSON.parse(await fs.readFile('./src/databases/user.json'))
        const idKey = coveredInfo.id

        const allUserInfo = JSON.parse(await fs.readFile('./src/databases/alluser.json'))
        allUserInfo.forEach((allUserInfos, index, arr) => {
            if (allUserInfos.id === idKey) {
                arr[index].product.push(body.product)
                arr[index].time.push(body.time)
                arr[index].price.push(body.price)
                arr[index].validity.push(addNumber(regexValidity))
                arr[index].seats.push("N")
                arr[index].loginTime.push("N")
                arr[index].logoutTIme.push("N")
                arr[index].initialEndtime.push(addNumber(regexTime))


                const diff = addNumber(regexTime).diff(moment(), "seconds")
                arr[index].remainedTime.push(diff)
            }
        }
        )
        await fs.writeFile('./src/databases/alluser.json', JSON.stringify(allUserInfo))
        return { success: true, msg: "선택 완료!" }

        // static async getKiocedata(body){

        //     function regexChange(time){
        //         var regex = /[^0-9]/g;				
        //         var regexResult = time.replace(regex, "N");
        //         addNumber(time, regexResult)
        //     }


        //     function addNumber(time, regexResult){
        //         var bodyPlus = "N"

        //             if (time.includes('시간')) {
        //                 bodyPlus = moment().add(regexResult, "hours")
        //               } else {
        //                 bodyPlus = moment().add(regexResult, "days")
        //             }
        //               return bodyPlus
        //         } 
    }

    /**키오스크 상품 삭제 */
    static async productDelete(body) {

        const array = JSON.parse(await fs.readFile('./src/databases/productDisplay.json'))
        array.forEach((obj, index) => {
            if (obj.price === body.deletePrice) {
                array.splice(index, 1);
            }
        });
        await fs.writeFile('./src/databases/productDisplay.json', JSON.stringify(array))
        return { success: true, msg: "삭제 완료!" }
    }

    /**키오스크 상품 수정 */
    static async productChange(body) {
        /**키오스크 상품 데이터 조회 */
        const kioskData = JSON.parse(await fs.readFile('./src/databases/productDisplay.json'))

        kioskData.forEach((kioskDatas, index) => {
            if (kioskDatas.product === body.originProduct && kioskDatas.price === body.originPrice) {
                kioskData.splice(index, 1, {
                    product: body.changeProduct,
                    price: body.changePrice,
                    time: body.changeTime,
                    validity: body.changeValidity,
                })
            }
        })

        await fs.writeFile('./src/databases/productDisplay.json', JSON.stringify(kioskData))
        return { success: true, msg: "수정 완료!" }
    }

    static async productPush(body) {
        const searchResult = JSON.parse(await fs.readFile('./src/databases/alluser.json'))

        searchResult.forEach((searchResults, index, arr) => {
            if (searchResults.id === body.id) {
                arr[index].product.push(body.product)
                arr[index].time.push(body.time)
                arr[index].price.push(body.price)
                // arr[index].validity.push(body.validity)
            }
        })
        await fs.writeFile('./src/databases/alluser.json', JSON.stringify(searchResult))
        return { success: true, msg: "지급 완료!" }
    }

    static async changeProduct(body) {
        /**최초 로그인시 들어왔던 상품에 대한 퇴실 처리 로직은 적용되지 않았음.
         이게 아니라 어차피 seats 설정시에만 로그인 타임이 들어가므로 상관없네.
         아주 엄밀하게는 고정석으로 들어가는 경우에는 seats를 보여주지말고
         문열기 버튼을 눌렀을 때.! 문만 열리게 코드를 짜야합니다. 
         */
        const coveredInfo = JSON.parse(await fs.readFile('./src/databases/user.json'))
        coveredInfo.product = body.changeProduct
        await fs.writeFile('./src/databases/user.json', JSON.stringify(coveredInfo))
        return { success: true, msg: "이용권 전환 완료!" }
    }



    static async selectSave(body) {
        const selectInfo = this.#selectInfo
        const allUserInfo = JSON.parse(await fs.readFile('./src/databases/alluser.json'))
        allUserInfo.forEach((allUserInfos, index, arr) => {
            if (allUserInfos.seats.includes(body.selectedSeats)) {
                selectInfo.id = arr[index].id
                const seatsArr = arr[index].seats
                /**해당 body.selectedSeats의 인덱스를 찾기 */
                const idx = seatsArr.findIndex(seatsArrs => seatsArrs === body.selectedSeats);
                selectInfo.seats = arr[index].seats[idx]
                selectInfo.product = arr[index].product[idx]
                selectInfo.phone = arr[index].phone
                selectInfo.remainedTime = arr[index].remainedTime[idx]
            }
        })
        await fs.writeFile('./src/databases/seatsSelect.json', JSON.stringify(selectInfo))
        return { success: true }
    }




    static async forcedDeparture(body) {
        const nowTime = moment();
        const allUserInfo = JSON.parse(await fs.readFile('./src/databases/alluser.json'))

        allUserInfo.forEach((allUserInfos, index, arr) => {
            if (allUserInfos.id === body.departureId) {
                const productArr = arr[index].product

                const idx = productArr.findIndex(productArrs => productArrs === body.departureProduct);
                arr[index].seats[idx] = "N"
                /* 좌석의 위치가 중요하다. 따라서 ''로 치환하겠음 
                logoutTIme[idx]을 nowTIme로 하는 것을 나중에 처리하는 비동기 처리가 나타날 수도 있네
                동기 vs 비동기 정확한 의미 아직도 모름.. 암튼 해결 방안은 알겠음*/
                arr[index].logoutTIme[idx] = nowTime
                arr[index].useTime[idx] = nowTime.diff(moment(arr[index].loginTime[idx]))
                const diff = arr[index].remainedTime[idx] - arr[index].useTime[idx]
                arr[index].remainedTime[idx] = diff
            }
        })

        await fs.writeFile('./src/databases/alluser.json', JSON.stringify(allUserInfo))
        return { success: true, msg: "강제 퇴실 완료!" }

    }


    /**찐 좌석 변경 촤종 */

    static async forcedFinalchange(body) {
        const selectUser = JSON.parse(await fs.readFile('./src/databases/seatsSelect.json'))
        const allUserInfo = JSON.parse(await fs.readFile('./src/databases/alluser.json'))

        allUserInfo.forEach((allUserInfos, index, arr) => {
            if (allUserInfos.id === selectUser.id) {
                const idx = arr[index].product.findIndex(products => products === selectUser.product)
                arr[index].seats[idx] = body.seats
            }
        })
        await fs.writeFile('./src/databases/alluser.json', JSON.stringify(allUserInfo))
        return { success: true, msg: "좌석 이동 완료" }
    }


    static async validityAdd(body) {
        const selectUser = JSON.parse(await fs.readFile('./src/databases/seatsSelect.json'))
        const allUserInfo = JSON.parse(await fs.readFile('./src/databases/alluser.json'))
        allUserInfo.forEach((allUserInfos, index, arr) => {
            if (allUserInfos.id === selectUser.id) {
                const idx = arr[index].product.findIndex(products => products === selectUser.product)
                var parsedValidity = moment(arr[index].validity[idx]);
                var bodyPlus = parsedValidity.add(body.addValidity, "days")
                /*add 함수는 JavaScript의 Date 객체에서 사용 가능한 함수로, 문자열에는 직접 적용할 수 없습니다. */
                arr[index].validity[idx] = bodyPlus
            }
        })
        await fs.writeFile('./src/databases/alluser.json', JSON.stringify(allUserInfo))
        return { success: true, msg: "유효 기간 추가 완료" }
    }

    static async validityDiff(body) {
        const selectUser = JSON.parse(await fs.readFile('./src/databases/seatsSelect.json'))
        const allUserInfo = JSON.parse(await fs.readFile('./src/databases/alluser.json'))
        allUserInfo.forEach((allUserInfos, index, arr) => {
            if (allUserInfos.id === selectUser.id) {
                const idx = arr[index].product.findIndex(products => products === selectUser.product)
                var parsedValidity = moment(arr[index].validity[idx]);
                console.log(body.diffValidity)
                var bodyMinus = parsedValidity.subtract(body.diffValidity, "days")
                /*add 함수는 JavaScript의 Date 객체에서 사용 가능한 함수로, 문자열에는 직접 적용할 수 없습니다. */
                arr[index].validity[idx] = bodyMinus
            }
        })
        await fs.writeFile('./src/databases/alluser.json', JSON.stringify(allUserInfo))
        return { success: true, msg: "유효 기간 차감 완료" }
    }

    static async timeAdd(body) {

        let timeArr = [];

        const selectUser = JSON.parse(await fs.readFile('./src/databases/seatsSelect.json'))
        const allUserInfo = JSON.parse(await fs.readFile('./src/databases/alluser.json'))
        allUserInfo.forEach((allUserInfos, index, arr) => {
            if (allUserInfos.id == selectUser.id) {
                const idx = arr[index].product.findIndex(products => products === selectUser.product)

                timeArr[0] = body.addDays
                timeArr[1] = body.addHours
                timeArr[2] = body.addMinutes

                timeArr.forEach((arr, index) => {
                    if (arr === "N") {
                        arr[index] = 0;
                    }
                });
                const addTime = timeArr[0] * 86400000 + timeArr[1] * 3600000 + timeArr[2] * 60000
                const changedTime = arr[index].remainedTime[idx] + addTime
                arr[index].remainedTime[idx] = changedTime

            }
        })
        await fs.writeFile('./src/databases/alluser.json', JSON.stringify(allUserInfo))
        return { success: true, msg: "시간 추가 완료" }
    }

    static async timeDiff(body) {
        let timeArr = [];

        const selectUser = JSON.parse(await fs.readFile('./src/databases/seatsSelect.json'))
        const allUserInfo = JSON.parse(await fs.readFile('./src/databases/alluser.json'))
        allUserInfo.forEach((allUserInfos, index, arr) => {
            if (allUserInfos.id === selectUser.id) {

                const idx = arr[index].product.findIndex(products => products === selectUser.product)
                timeArr[0] = body.diffDays
                timeArr[1] = body.diffHours
                timeArr[2] = body.diffMinutes

                timeArr.forEach((arr, index) => {
                    if (arr === "N") {
                        arr[index] = 0;
                    }
                });

                const diffTime = timeArr[0] * 86400000 + timeArr[1] * 3600000 + timeArr[2] * 60000
                const changedTime = arr[index].remainedTime[idx] - diffTime

                arr[index].remainedTime[idx] = changedTime
            }
        })
        await fs.writeFile('./src/databases/alluser.json', JSON.stringify(allUserInfo))
        return { success: true, msg: "시간 차감 완료" }
    }

    static async forcedStart(body) {
        if (body.product.includes("현재 이용중")) {
            return { success: false, msg: "현재 사용중인 이용권입니다. 선택불가!" }
        } else {
            const nowTime = moment();
            const select = JSON.parse(await fs.readFile('./src/databases/seatsSelect.json'))
            const allUserInfo = JSON.parse(await fs.readFile('./src/databases/alluser.json'))
            allUserInfo.forEach((allUserInfos, index, arr) => {
                if (allUserInfos.phone === body.phone) {
                    const productArr = arr[index].product
                    const idx = productArr.findIndex(productArrs => productArrs === body.product);

                    arr[index].seats.forEach((newarr, resetIdx) => {
                        if (newarr !== "N") {
                            /**잔여 시간 갱신, diff랑 subtract 차이를 모르겠음
                             diff는 단순 두 날짜간의 차이 & subtract는 특정 값에 해당하는 days, minutes 등을 빼는 것
                             subtract와 add가 반대임. diff의 반대는... 굳이 알아야 하나?? 
                            */
                            const useTime = moment.duration(nowTime.diff(moment(arr[index].loginTime[resetIdx])))
                            const newRemained = arr[index].remainedTime[resetIdx] - useTime
                            arr[index].remainedTime[resetIdx] = newRemained
                            /**기존 좌석의 로그인 시간과 좌석 정보를 초기화 */
                            arr[index].seats[resetIdx] = "N"
                            arr[index].loginTime[resetIdx] = "N"
                            arr[index].logoutTIme[resetIdx] = nowTime
                        }
                    })
                    arr[index].loginTime[idx] = nowTime
                    arr[index].seats[idx] = select.seats
                }
            })

            await fs.writeFile('./src/databases/alluser.json', JSON.stringify(allUserInfo))
            return { success: true, msg: "강제 시작 완료!" }
        }

    }

    static async adminStart(body) {
        /**관리자도 강제퇴실을 좀 하자. */
        const nowTime = moment();
        var regex = /[^0-9]/g;
        var regexHours = body.adminHours.replace(regex, "N")
        var regexMinutes = body.adminMinutes.replace(regex, "N")


        // 더할 시간의 객체를 만든다. 이렇게 하면 moment js에서 알아서 시간/분 처리해줌

        // 현재 시간에 시간과 분을 동시에 더한다. 객체로 더하는 방법도 있다. 

        /**나중에 change.json을 버리고 seatsSelect.json만 가지고 놀기. 비슷한 속성은 하나만 두자
         * 또한 admin은 미리 alluser.json에 만들어놓자. 조건문 주렁주렁 달면 보기 안좋다. 
         */

        /**시간/분 더하기입니다. add, substract는 파라미터로 문자열이 아니라 숫자만 받으므로 반드시 parseint 매서드를 써야 */


        const timeObj = {
            "hours": regexHours,
            "minutes": regexMinutes

        }

        const adminEndtime = moment().add(timeObj)


        const select = JSON.parse(await fs.readFile('./src/databases/seatsSelect.json'))

        const allUserInfo = JSON.parse(await fs.readFile('./src/databases/alluser.json'))
        allUserInfo.forEach((allUserInfos, index, arr) => {
            if (allUserInfos.id === "admin") {
                arr[index].product.push("admin")
                arr[index].time.push("N")
                arr[index].validity.push(adminEndtime)
                arr[index].seats.push(select.seats)
                var timeDIff = adminEndtime.diff(nowTime)
                arr[index].remainedTime.push(timeDIff)
            }
        })

        await fs.writeFile('./src/databases/alluser.json', JSON.stremainedTImeringify(allUserInfo))
        return { success: true, msg: "강제 시작 완료!" }
    }

    static async typeChange(body) {
        const select = JSON.parse(await fs.readFile('./src/databases/seatsSelect.json'))
        const type = JSON.parse(await fs.readFile('./src/databases/seatsType.json'))

        /**원래 이렇게 변수 치환해야 되냐? */
        const seatsInfo = select.seats


        /**좌석 정보를 가지고 타입 조회 */
        function getKeyByValue(type, seatsInfo) {
            return Object.keys(type).find(key => type[key].includes(seatsInfo));
        }

        let filtered = type[getKeyByValue(type, seatsInfo)].filter((element) => element !== seatsInfo);

        /**filtered된 배열로 치환 및 삽입 */
        type[getKeyByValue(type, seatsInfo)] = filtered

        console.log(type[body.seatsType])

        type[body.seatsType].push(seatsInfo)

        await fs.writeFile('./src/databases/seatsType.json', JSON.stringify(type))
        return { success: true, msg: "타입 변경 완료" }
    }

    /**초기 화면에서 매번 10초마다 리로드를 시켜서 로그인 한 유저의 경우에는 
     * 현재시간과 로그인 시간의 차이를 구하고 (usetime) 이를 remainedTime에 뺀다. 
     * 파일을 write 하고 (여기서 콜백함수 쓰는게 깔끔한데) 남은 시간과 유효 기간 배열에서 음수인 요소가
     * 존재함을 확인하면 된다. 
     */
    static async timeCheck() {

        const allUserInfo = JSON.parse(await fs.readFile('./src/databases/alluser.json'))

        /**잔여시간이 없는지, 유효기간이 지났는지 여부 체크 */
        allUserInfo.forEach((array) => {
            const idx = array.remainedTime.findIndex((ele) => ele < 0);
            if (idx !== -1) {
                array.remainedTime[idx] = "N"
                array.product[idx] = "N"
                array.seats[idx] = "N"
                array.time[idx] = "N"
                array.validity[idx] = "N"
                array.loginTime[idx] = "N"
                array.logoutTime[idx] = "N"
            }
            const index = array.validity.findIndex((ele) => moment().diff(moment(ele), "days") > 0);

            if (index !== -1) {
                array.remainedTime[idx] = "N"
                array.product[idx] = "N"
                array.seats[idx] = "N"
                array.time[idx] = "N"
                array.validity[idx] = "N"
                array.loginTime[idx] = "N"
                array.logoutTime[idx] = "N"
            }

        });

        await fs.writeFile('./src/databases/alluser.json', JSON.stringify(allUserInfo))


    }

    /**로그인한 유저들을 대상으로 잔여 시간을 갱신시키는 알고리즘 */
    static async timeRenewal() {
        const allUserInfo = JSON.parse(await fs.readFile('./src/databases/alluser.json'))
        allUserInfo.forEach((array) => {
            const idx = array.loginTime.findIndex((ele) => ele !== "N");
            if (idx !== -1) {
                const useTime = moment().diff(array.loginTime[idx])
                array.remainedTime[idx] = array.remainedTime[idx] - useTime
            }

        });

        await fs.writeFile('./src/databases/alluser.json', JSON.stringify(allUserInfo))
    }

}
module.exports = UserStorage


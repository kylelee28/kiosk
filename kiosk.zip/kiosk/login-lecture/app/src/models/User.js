"use strict"

const UserStorage = require("./UserStorage")
const fs = require("fs").promises
const moment = require('moment');


class User {
    constructor(body) {
        this.body = body;
    }

    async login() {
        const body = this.body;

        const { id, psword } = await UserStorage.getUserInfo(body.loginId)

        if (id) {
            if (!body.loginPsword) {
                return { success: false, msg: "비밀번호를 입력해주세요" }
            }
            if (id === body.loginId && psword === body.loginPsword) {

                return { success: true }
            }
            return { success: false, msg: "비밀번호가 틀렸습니다." }
        }
        return { success: false, msg: "존재하지 않는 아이디입니다." }
    }




    async logout() {
        const body = this.body;
        const { id, psword } = await UserStorage.getlogoutInfo(body.logoutId)


        if (id) {
            if (!body.logoutPsword) {
                return { success: false, msg: "비밀번호를 입력해주세요" }
            }
            if (id === body.logoutId && psword === body.logoutPsword) {

                return { success: true }
            }
            return { success: false, msg: "비밀번호가 틀렸습니다." }
        }
        return { success: false, msg: "존재하지 않는 아이디입니다." }
    }


    /**adminkioce에서의 컨트롤러.
     * 차례 대로 상품 추가/상품 수정/상품 삭제
     */
    async adminControl() {
        const body = this.body
        if (body.addProduct) {
            const response = await UserStorage.listSave(body)
            return response
        }
        if (body.changeProduct) {
            const response = await UserStorage.productChange(body)
            return response
        }
        if (body.deleteProduct) {
            const response = await UserStorage.productDelete(body)
            return response
        }

    }


    // async makeFolder(){
    //     const idKey = this.body.id
    //     const filePath = `./src/name/${idKey}.json`
    //     try {
    //         await fs.access(filePath);
    //         console.log(`파일이 존재합니다: ${filePath}`);
    //     } catch (err) {
    //         await fs.writeFile(`./src/name/${idKey}.json`, JSON.stringify(UserStorage.getArrayInfo(), null))
    //     }

    // }


    /**여기는 변수 이름 수정할 필요가 없는데? */
    async register() {
        const id = this.body.id
        const psword = this.body.psword
        const phone = this.body.phone

        const confirmedPsword = this.body.confirmedPsword
        if (id) {
            if (psword !== confirmedPsword) {
                return { success: false, msg: "비밀번호를 확인해주십시오" }
            } else if (psword === confirmedPsword) {
                try {
                    const response = await UserStorage.save(this.body)
                    return response
                }
                catch (err) {
                    return { success: false, msg: err }
                }
            }
        }
        return { success: false, msg: "아이디를 입력해주십시요" }
    }

    async pushSet() {
        const body = this.body;
        const response = await UserStorage.setSave(body)
        return response
    }


    async pushDays() {
        const body = this.body;
        const response = await UserStorage.daysSave(body)
        return response
    }

    async kiocedata() {
        const body = this.body;
        const response = await UserStorage.getKiocedata(body)
        return response
    }

    async kioceObj() {
        const body = this.body
        const response = await UserStorage.objFilter(body)
        return response
    }

    async kioceObjChange() {
        const body = this.body
        const response = await UserStorage.productChange(body)
        return response
    }

    async adminManagement() {
        const body = this.body
        const response = await UserStorage.productPush(body)
        return response
    }

    async changeTicket() {
        const body = this.body
        const response = await UserStorage.changeProduct(body)
        return response
    }

    async seatsControl() {
        const body = this.body
        if (body.changeProduct) {
            const response = await UserStorage.forcedChange(body)
            return response
        }
        if (body.departureProduct) {
            const response = await UserStorage.forcedDeparture(body)
            return response
        }
        if (body.selectedSeats) {
            /**select.json에 기록 */
            const response = await UserStorage.selectSave(body)
            return response
        }
        if (body.phone) {
            /**강제 시작 */
            const response = await UserStorage.forcedStart(body)
            return response
        }
        if (body.adminHours) {
            /**관리자 강제 시작 */
            const response = await UserStorage.adminStart(body)
            return response
        }
        if (body.seatsType) {
            /**관리자 좌석 타입 변경 */
            const response = await UserStorage.typeChange(body)
            return response
        }

    }

    async seatsChange() {
        const body = this.body
        const response = await UserStorage.forcedFinalchange(body)
        return response
    }

    async detailControl() {

        const body = this.body

        if (body.departureProduct) {
            const response = await UserStorage.forcedDeparture(body)
            return response
        }
        if (body.selectedSeats) {
            const response = await UserStorage.selectSave(body)
            return response
        }
        if (body.addValidity) {
            const response = await UserStorage.validityAdd(body)
            return response
        }
        if (body.diffValidity) {
            const response = await UserStorage.validityDiff(body)

            return response
        }
        if (body.addDays) {
            const response = await UserStorage.timeAdd(body)
            return response
        }
        if (body.diffDays) {
            const response = await UserStorage.timeDiff(body)
            return response
        }

    }


}

module.exports = User;
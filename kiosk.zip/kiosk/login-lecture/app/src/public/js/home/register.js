"use strict";

const id = document.querySelector("#id"),
    name = document.querySelector("#name"),
    phone = document.querySelector("#phone")
psword = document.querySelector("#psword"),
    confirmedPsword = document.querySelector("#confirmed-psword"),
    registerBtn = document.querySelector("#registerBtn");

registerBtn.addEventListener("click", register)


function register() {
    const req = {
        id: id.value,
        name: name.value,
        phone: phone.value,
        psword: psword.value,
        confirmedPsword: confirmedPsword.value,
    }
    console.log(req)

    fetch("/register", {
        method: "POST",
        //get, post, put, delete, 조회, 생성, 수정, 삭제
        headers: {
            "Content-Type": "application/json"
        },
        //clients가 전달받고자 하는 데이터 형태
        body: JSON.stringify(req)
    })
        .then((res) => res.json())
        .then((res) => {
            if (res.success) {
                location.href = "/login"
            } else {
                alert(res.msg)
            }
        })
        .catch((err) => {
            console.error("로그인 중 오류 발생")
        });

}




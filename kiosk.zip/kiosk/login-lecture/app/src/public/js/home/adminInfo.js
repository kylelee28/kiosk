"use strict"


const navbar = document.querySelector(".navbar-toggler")

navbar.addEventListener("click", function(){
    document.querySelector('.list-group').classList.toggle('show')
})




"use strict"

const buttonRow = document.querySelector(".button-row")

buttonRow.addEventListener("click", function (e) {
  btnChange(e.target.dataset.set)
})


function btnChange(event) {

  modal.style.display = "flex";

  const req = {
    "seats": event
  }

  /**모달창 내 좌석명*/
  document.getElementById("changeNumber").innerText = event


  const seatChange = document.getElementById("seatchange")
  seatChange.addEventListener("click", function () {
    fetch("/adminseatschange", {
      method: "POST",
      //get, post, put, delete, 조회, 생성, 수정, 삭제
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(req)
    }

    )

      .then((res) => res.json())
      .then((res) => {

        if (res.success) {
          alert(res.msg)
        }
      })
      .catch((err) => {
        console.error("좌석 이동 중 오류 발생")
      })
  })



}


//모달창의 x를 누르면 모달창이 사라진다.  
const closeBtn = modal.querySelector(".close-area");
closeBtn.addEventListener("click", evt => {
  modal.style.display = "none";
});

//모달창의 바깥 영역을 클릭하면 꺼지게 한다.
modal.addEventListener("click", e => {
  const evTarget = e.target;
  if (evTarget.classList.contains("modal-overlay")) {
    modal.style.display = "none";
  }
});

// esc 버튼을 누르면 모달창 닫기
window.addEventListener("keyup", e => {
  if (modal.style.display == "flex" && e.key == "Escape") {
    modal.style.display = "none";
  }
}
);


addEventListener("load", inUse)

var count = 0;

function inUse() {

  fetch('alluserInfo')
    .then((response) => response.json())
    .then((json) => {
      json.forEach((jsons, index, arr) => {
        if (jsons.seats.length !== 0) {
          for (var value of arr[index].seats) {
            if (value !== "N") {
              textChange(value)
            }
          }
        }
      })
    })
}

function textChange(value) {
  document.getElementById(`${value}`).innerText = "사용중"
  count++;
  document.getElementById('number').innerText = count
}


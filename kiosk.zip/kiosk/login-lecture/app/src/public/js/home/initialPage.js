"use strict";

/**f2누르면 일괄적으로 rename할 수 있다. */
const id = document.querySelector("#id")
const psword = document.querySelector("#psword")
const loginBtn = document.querySelector("#loginBtn");

const id2 = document.querySelector("#id3")
const psword2 = document.querySelector("#psword3")
const loginBtn2 = document.querySelector("#loginBtn3");

const id3 = document.querySelector("#id3")
const psword3 = document.querySelector("#psword3")
const loginBtn3 = document.querySelector("#loginBtn3");



/**로그인 부분, 문열기는 아직 다루지 않겠음 */

loginBtn.addEventListener("click", login)


function login() {
    const req = {
        loginId : id.value,
        loginPsword : psword.value,
    }

    fetch("/initialPage", {
        method : "POST",
        //get, post, put, delete, 조회, 생성, 수정, 삭제
        headers : {
            "Content-Type" : "application/json"
        },
        //clients가 전달받고자 하는 데이터 형태
        body : JSON.stringify(req)
    })
    .then((res) => res.json())
    .then((res) => {

  
    if (res.success) {
        location.href = "/kioceinfo"
    } else {
        alert(res.msg) 
    }
})
    .catch((err) => {
        console.error("로그인 중 오류 발생")
    });
    
}

// /**키입력 이벤트 발생하는 것을 감지하는 코드,
//  * setinterval을 이용해서 지속적으로 로그인 정보를 던지다가 키 입력이벤트가 발생하면
//  * 해당행위를 중단한다. */    
// id.addEventListener('keyup', function(){
//     console.log("반복중지")
//     clearInterval(interval)
//   });

//   let interval = setInterval(login, 3000);


// /**일정시간 동안 움직임이 없으면 초기화하는 코드 */
// let idleTime = 0;
// document.addEventListener('DOMContentLoaded', function () {
//     // 1분마다 일정시간 움직임이 있으면 초기화
//     let idleInterval = setInterval(timerIncrement, 1000);
    
//     // 마우스 이동 시 및 키 입력 시 idleTime을 초기화합니다.
//     document.addEventListener('mousemove', function (e) { 
//         idleTime = 0; 
//     });
    
//     document.addEventListener('keypress', function (e) { 
//         idleTime = 0; 
//     });
// });


// function timerIncrement() {
//     idleTime = idleTime + 1;
//     // 30초 이상 움직임이 없으면 페이지 새로고침 및 경로 이동
//     if (idleTime > 30) { 
//         window.location.reload();
//     }
// }
// /**페이지 새로고침시 바로 로그인 탭이 보이도록 코드를 짜야된다. */



/**탭기능 만드는법 숙지 */
const $nav = document.querySelector('#tab-button-nav')
const $sections = document.querySelectorAll('.tab-section');

$nav.addEventListener('click', (e) => {
  if (!e.target.classList.contains('tab')) {
    return;
  }
  
  const focusedTabId = e.target.dataset.tabSection;

  $sections.forEach(($section) => {
    if ($section.id === focusedTabId) {
      $section.removeAttribute('hidden');
    } else {
      $section.setAttribute('hidden', true);
    }
  });
});

/**로그아웃 페이지 부분 */

loginBtn3.addEventListener("click", logout)


function logout() {
    const req = {
        logoutId : id3.value,
        logoutPsword : psword3.value,
    }
    console.log(req)
    fetch("/initialPage", {
        method : "POST",
        //get, post, put, delete, 조회, 생성, 수정, 삭제
        headers : {
            "Content-Type" : "application/json"
        },
        //clients가 전달받고자 하는 데이터 형태
        body : JSON.stringify(req)
    })
    .then((res) => res.json())
    .then((res) => {

  
    if (res.success) {
        modal.style.display = "flex";
        fetchPage()
        
         //모달창의 x를 누르면 모달창이 사라진다.
         const closeBtn = modal.querySelector(".close-area");
         closeBtn.addEventListener("click", evt => {
            dynamicTable.innerHTML = ""
             modal.style.display = "none";
             
         });
        
         //모달창의 바깥 영역을 클릭하면 꺼지게 한다.
         modal.addEventListener("click", e=>{
            const evTarget = e.target;
            if(evTarget.classList.contains("modal-overlay")){
                dynamicTable.innerHTML = ""
                modal.style.display="none";
            }
         });
        
         // esc 버튼을 누르면 모달창 닫기
         window.addEventListener("keyup", e=>{
            if(modal.style.display == "flex" && e.key=="Escape"){
                dynamicTable.innerHTML = ""
                modal.style.display="none";
            }
         }
         );

         /**모달창 내부의 표 선택하면 css 입힘 */
         dynamicTable.addEventListener('click', function(event) {

            if (event.target.tagName === 'TD') {
          
              const prevSelectedRow = document.querySelector('.selected');
              if (prevSelectedRow) {
                prevSelectedRow.classList.remove('selected');
              }
              const selectedRow = event.target.parentNode;
              selectedRow.classList.add('selected');
            }}
            
            )


         function fetchPage() {
            fetch('alluserinfo')
                  .then((response) => response.json())
                  .then((json) => { 
                    displayData(json)
                    })
                  }


                function displayData(json){
                    json.forEach((jsons, index, arr)=>{
                        if(jsons.id === id3.value){
                            for(let i = 0; i < arr[index].product.length; i++){
      
                              const row = dynamicTable.insertRow();
                            
                              const cell1 = row.insertCell(0);
                              cell1.appendChild(document.createTextNode(arr[index].product[i]));
                            
                              const cell2 = row.insertCell(1);
                              cell2.appendChild(document.createTextNode(arr[index].seats[i]));
                            
                              const cell3 = row.insertCell(2);
                              cell3.appendChild(document.createTextNode(arr[index].remainedTime[i]));
                            
                              const cell4 = row.insertCell(3);
                              cell4.appendChild(document.createTextNode(arr[index].validity[i]));
                              }
                            
                            
                            
                            
                        } 
                      })
                }

        

         /**퇴실 처리한 이용권 정보를 서버측에서 ""로 만들고 초기페이지로 만들고 모달창 꺼진다. */
        const checkOut = document.getElementById("checkOut")
        checkOut.addEventListener("click", function(){
            const selectedRow = document.querySelector('.selected');
         if (selectedRow){
         const cells = selectedRow.cells
         const req = {
        checkProduct : cells[0].textContent,
        checkSeats : cells[1].textContent,
        checkRemainedTime : cells[2].textContent,
        checkValidity : cells[3].textContent
        }

        console.log(req)
            fetch("/initialPage", {
                method : "POST",
                //get, post, put, delete, 조회, 생성, 수정, 삭제
                headers : {
                    "Content-Type" : "application/json"
                },
                //clients가 전달받고자 하는 데이터 형태
                body : JSON.stringify(req)
            })
            .then((res) => res.json())
            .then((res) => {
                if(res.success){
                    alert(res.msg)
                    modal.style.display="none"
                    dynamicTable.innerHTML = ""
                }
            })
            
        }})
        
    } 
})
    .catch((err) => {
        console.error("로그아웃 중 오류 발생")
    });
    
}




 
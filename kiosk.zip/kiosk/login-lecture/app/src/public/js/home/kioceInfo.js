"use strict"

const myProduct = document.getElementById("myProduct")
const myRemainedtime = document.getElementById("myTime")
const myValidity = document.getElementById("myValidity")
const changeTicket = document.getElementById("changeTicket")
const myName = document.getElementById("bottom-title")
const buyTicket = document.getElementById("buyTicket")
const selectSeat = document.getElementById("selectSeat")


//초기 id 값을 fetch로 불러오고 해당 id를 파라미터로 넘긴다.

addEventListener("load", fetchInfo())

function fetchInfo() {
  fetch('coveredinfo')
    .then((response) => response.json())
    .then((json) => {
      const idKey = json.id;
      const productKey = json.product;
      myName.innerHTML = idKey;
      myProduct.innerHTML = productKey;
      filterData(idKey, productKey)

    })

}

//초기 id를 파라미터로 받고 해당 id와 일치하는 객체를 추출한다. 
//& 모달창에 해당 id의 product, remainedTime, validity 목록을 보여준다. 

function filterData(idKey, productKey) {

  fetch('alluserInfo')
    .then((response) => response.json())
    .then((json) => {
      json.forEach((jsons, index, arr) => {
        if (jsons.id === idKey) {
          const idx = arr[index].product.indexOf(productKey)

          const rawTime = arr[index].remainedTime[idx]
          const rawValidity = arr[index].validity[idx]

          const allData = arr[index]

          changeData(rawTime, rawValidity)

          Productdata(allData)

        }
      })
    }
    )
}

//남은 시간이 가장 많은 상품 정보를 브라우저에 보여준다.
function changeData(rawTime, rawValidity) {

  myRemainedtime.innerHTML = humanReadable(rawTime)
  myValidity.innerHTML = rawValidity

  function humanReadable(time) {
    if (time < 61) {
      return '00:' + addZero(time)
    }
    var days = Math.floor((time / 86400))
    var hours = Math.floor((time - days * 86400) / 3600)
    var mins = Math.floor((time - (hours * 3600 + days * 86400)) / 60)
    var secs = time - days * 86400 - hours * 3600 - mins * 60
    return addZero(days) + "일" + addZero(hours) + '시간' + addZero(mins) + '분' + addZero(secs) + '초'
  }

  function addZero(num) {
    return ((num < 10) ? '0' : '') + num
  }

}


/**kioce와 seats로의 이동 */
buyTicket.addEventListener("click", function () {
  location.href = "/kioce"
})

selectSeat.addEventListener("click", function () {
  location.href = "/seats"
})



//모달창에서의 테이블 생성 
function Productdata(allData) {

  //남은 시간 배열의 각 요소에 대해서 함수를 순회하여 실행시킨다. 
  function humanReadable(rawTime) {
    if (rawTime < 61) {
      return '00:' + addZero(rawTime)
    }
    var days = Math.floor((rawTime / 86400))
    var hours = Math.floor((rawTime - days * 86400) / 3600)
    var mins = Math.floor((rawTime - (hours * 3600 + days * 86400)) / 60)
    var secs = rawTime - days * 86400 - hours * 3600 - mins * 60
    return addZero(days) + "일" + addZero(hours) + '시간' + addZero(mins) + '분' + addZero(secs) + '초'
  }


  function addZero(num) {
    return ((num < 10) ? '0' : '') + num
  }


  for (let i = 0; i < allData.product.length; i++) {

    console.log(humanReadable(allData.remainedTime[i]));

    const row = dynamicTable.insertRow();

    const cell1 = row.insertCell(0);
    cell1.appendChild(document.createTextNode(allData.product[i]));

    const cell2 = row.insertCell(1);
    cell2.appendChild(document.createTextNode(humanReadable(allData.remainedTime[i])));

    const cell3 = row.insertCell(2);
    cell3.appendChild(document.createTextNode(allData.validity[i]));

    const change = document.getElementById("change")
    change.addEventListener("click", changeButton)

  }

}


//모달창 내의 테이블의 특정 행을 클릭하면 selected로 보여준다. 
dynamicTable.addEventListener('click', function (event) {

  if (event.target.tagName === 'TD') {

    const prevSelectedRow = document.querySelector('.selected');
    if (prevSelectedRow) {
      prevSelectedRow.classList.remove('selected');
    }
    const selectedRow = event.target.parentNode;
    selectedRow.classList.add('selected');
  }
})


//모달창에서의 서버와의 통신 : 그냥 서버에는 상품명만 던지고 user.json에서 해당 상품명 기입
//이렇게 되면 클라이언트측에도 바뀐 정보가 나타난다. 

function changeButton() {
  const selectedRow = document.querySelector('.selected');
  if (selectedRow) {
    const cells = selectedRow.cells
    const req = {
      changeProduct: cells[0].textContent,
    }
    console.log(req)


    fetch("/kioceInfo", {
      method: "POST",
      //get, post, put, delete, 조회, 생성, 수정, 삭제
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(req)
    }
    )

      .then((res) => res.json())
      .then((res) => {

        if (res.success) {
          alert(res.msg)

        }
      })
      .catch((err) => {
        console.error("이용권 전환 중 오류 발생")
      })


  }
}




changeTicket.addEventListener("click", e => {

  modal.style.display = "flex";
});

//모달창의 x를 누르면 모달창이 사라진다.
const closeBtn = modal.querySelector(".close-area");
closeBtn.addEventListener("click", evt => {
  modal.style.display = "none";
});

//모달창의 바깥 영역을 클릭하면 꺼지게 한다.
modal.addEventListener("click", e => {
  const evTarget = e.target;
  if (evTarget.classList.contains("modal-overlay")) {
    modal.style.display = "none";
  }
});

// esc 버튼을 누르면 모달창 닫기
window.addEventListener("keyup", e => {
  if (modal.style.display == "flex" && e.key == "Escape") {
    modal.style.display = "none";
  }
}
);

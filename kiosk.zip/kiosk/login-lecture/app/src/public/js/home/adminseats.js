"use strict";


const dynamicTable = document.getElementById("dynamicTable")
const userInfo = document.getElementById("userInfo")
// 새로운 모달 변수
const newModal = document.getElementById("newModal");
const search = document.getElementById("search")
const inputPhone = document.getElementById("inputPhone")
const forcedStart = document.getElementById("forcedStart")
const adminStart = document.getElementById("adminStart")
const typeChange = document.getElementById("typeChange")

/**이벤트 버블링을 이용해서 각 버튼들의 부모요소인 button-row 클래스에 대해서 
 * 이벤트 리스너를 쓴다. e.target.dataset.set은 1set, 2set, 3set 등등 가리킴
 */

const buttonRow = document.querySelector(".button-row")

buttonRow.addEventListener("click", function (e) {
  btnChange(e.target.dataset.set)
})


var product = document.querySelector('.product');
var hours = document.querySelector('.hours');
var minutes = document.querySelector('.minutes');
var seatsType = document.querySelector('.seatsType');

/**반복문을 통해 리로드 됐을 때 시간/분 옵션 태그 텍스트 추가 */
addEventListener("load", function () {
  for (var i = 0; i < 24; i++) {
    var option = document.createElement('option');
    option.text = `${i}시간`;
    hours.append(option);
  }
  for (var i = 0; i < 7; i++) {
    var option = document.createElement('option');
    option.text = `${i}0분`;
    minutes.append(option);
  }
})

/**내가 adminseats에서 클릭한 좌석을 서버로 던진다.
 * 이를 통해 해당 좌석을 점유하는 유저의 아이디, 좌석, 남은시간, 이용티켓을 알 수 있다.
 */

function btnChange(event) {
  const req = {
    selectedSeats: event
  }

  fetch("/adminseats", {
    method: "POST",
    //get, post, put, delete, 조회, 생성, 수정, 삭제
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(req)
  }

  )

    .then((res) => res.json())
    .then((res) => {

      if (res.success) {

      }
    })
    .catch((err) => {
      console.error("좌석 선택 오류 발생")
    })



  /*조건절에서는 =이 아니라 ===! */
  if (document.getElementById(`${event}`).innerText === "사용중") {
    modal.style.display = "flex";

    /**어떤 좌석 버튼 클릭시 filterData 호출하겠음.
     * * 해당 좌석의 정보를 가져오는 함수임 */
    filterData()

  } else {
    newModal.style.display = "flex";
    document.getElementById("seatsName1").innerText = `${event}`
    document.getElementById("seatsName2").innerText = `${event}`

    /**관리자 페이지에서 좌석 타입 조회  */

    fetch('typeInfo')
      .then((response) => response.json())
      .then((json) => {
        document.getElementById("type").innerText = `${getKeyByValue(json, event)}`
      }
      )
    typeChange.addEventListener("click", function () {

      const req = {
        seatsType: seatsType.options[seatsType.selectedIndex].value
      }
      fetch("/adminseats", {
        method: "POST",
        //get, post, put, delete, 조회, 생성, 수정, 삭제
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(req)
      }

      )

        .then((res) => res.json())
        .then((res) => {

          if (res.success) {

          }
        })
        .catch((err) => {
          console.error("타입 변경 중 오류 발생")
        })
    })

  }

  /**object의 value를 통해 key를 찾는 함수 */
  function getKeyByValue(json, event) {
    return Object.keys(json).find(key => json[key].includes(event));
  }

}


function filterData() {

  fetch('selectInfo')
    .then((response) => response.json())
    .then((json) => {

      const row = dynamicTable.insertRow();

      const cell1 = row.insertCell(0);
      cell1.appendChild(document.createTextNode(json.id));

      const cell2 = row.insertCell(1);
      cell2.appendChild(document.createTextNode(json.phone));

      const cell3 = row.insertCell(2);
      cell3.appendChild(document.createTextNode(json.product));

      const cell4 = row.insertCell(3);
      cell4.appendChild(document.createTextNode(json.remainedTime));

    })
}


/**검색 버튼 눌러 이용자 폰 번호를 필터해서 서버로부터 이용권 배열 획득 */
search.addEventListener("click", function () {
  fetch('alluserinfo')
    .then((response) => response.json())
    .then((json) => {


      /**loginTIme 배열에서 무조건 하나의 원소만 ""이 아닐 수가 있다. 따라서 ""이 아닌 문자열이 위치한
       * idx를 잡고 그 idx에 해당되는 product는 사용 불가해야 한다. 그래서 filteredProduct[idx]에는 특정 문자열을
       * 같이 넣어가지고 재할당을 한다. 그후 특정 문자열이 포함된 body가 있는 경우 서버측에서 msg를 내보낸다. 
       */
      json.forEach((jsons, index, arr) => {
        if (jsons.phone === inputPhone.value) {
          var filteredProduct = arr[index].product
          const filteredLogin = arr[index].loginTime
          const idx = filteredLogin.findIndex(filteredLogins => filteredLogins !== "");
          var content = filteredProduct[idx]
          filteredProduct[idx] = `${content}(현재 이용중, 선택 불가)`

          product.innerHTML = ""
          for (var i = 0; i < filteredProduct.length; i++) {
            var option = document.createElement('option');
            option.text = filteredProduct[i];
            product.append(option);
          }
        }
      })
    })

}
)

/**강제 시작 버튼을 누르면 phone으로 해당 유저의 상품의 로그인 타임을 현재 시간으로 한다.
 * 일단 그전에 로그인 타임과 로그아웃 타임도 배열로 만들어서 상품과 idx를 일치시켜야 한다.
 */
forcedStart.addEventListener("click", function () {
  const req = {
    phone: inputPhone.value,
    product: product.options[product.selectedIndex].value
  }

  fetch("/adminseats", {
    method: "POST",
    //get, post, put, delete, 조회, 생성, 수정, 삭제
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(req)
  }

  )

    .then((res) => res.json())
    .then((res) => {
      /**res.success의 의미가 success : true라는 것을 몰랐던 인간 */
      alert(res.msg)

    })
    .catch((err) => {
      console.error("강제 시작 중 오류 발생")
    })

})

/**관리자 점유 시작, selected box 내용을 req로 서버에 전달
 * 해당 시간/분 값을 정규식을 통해서 서버에 기록하고 id를 admin으로
 로그인/로그아웃/상품명/시간/유효기간 = ""로 보내고 남은시간과 자리만 실젯값으로
 */

adminStart.addEventListener("click", function () {
  const req = {
    adminHours: hours.options[hours.selectedIndex].value,
    adminMinutes: minutes.options[minutes.selectedIndex].value
  }

  fetch("/adminseats", {
    method: "POST",
    //get, post, put, delete, 조회, 생성, 수정, 삭제
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(req)
  }

  )

    .then((res) => res.json())
    .then((res) => {
      if (res.success) {
        alert(res.msg)
      }


    })
    .catch((err) => {
      console.error("관리자 점유 시작 중 오류 발생")
    })

})




//모달창의 x를 누르면 모달창이 사라진다.  
const closeBtn = modal.querySelector(".close-area");
closeBtn.addEventListener("click", evt => {
  modal.style.display = "none";
  dynamicTable.innerHTML = ""
});

//모달창의 바깥 영역을 클릭하면 꺼지게 한다.
modal.addEventListener("click", e => {
  const evTarget = e.target;
  if (evTarget.classList.contains("modal-overlay")) {
    modal.style.display = "none";
  }
});

// esc 버튼을 누르면 모달창 닫기
window.addEventListener("keyup", e => {
  if (modal.style.display == "flex" && e.key == "Escape") {
    modal.style.display = "none";
  }
}
);


/**좌석 이동 버튼 누르면 굳이 모달창 내부의 표의 값을 선택안해도
 * 좌석 이동 페이지로 넘어가게 할 것.
 */
const seatChangebutton = document.getElementById("seatchange")
seatChangebutton.addEventListener("click", () => {
  location.href = "/adminseatschange"
})


dynamicTable.addEventListener('click', function (event) {
  if (event.target.tagName === 'TD') {

    const prevSelectedRow = document.querySelector('.selected');
    if (prevSelectedRow) {
      prevSelectedRow.classList.remove('selected');
    }
    const selectedRow = event.target.parentNode;
    selectedRow.classList.add('selected');

  }
})


const departureButton = document.getElementById("departure")
departureButton.addEventListener("click", departure)



function departure() {
  const selectedRow = document.querySelector('.selected');
  console.log(selectedRow)
  if (selectedRow) {
    const cells = selectedRow.cells
    const req = {
      departureId: cells[0].textContent,
      departureProduct: cells[2].textContent,
    }

    console.log(req)

    fetch("/adminseats", {
      method: "POST",
      //get, post, put, delete, 조회, 생성, 수정, 삭제
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(req)
    }

    )

      .then((res) => res.json())
      .then((res) => {

        if (res.success) {
          alert(res.msg)
        }
      })
      .catch((err) => {
        console.error("강제 퇴실 오류 발생")
      })
  }

}


userInfo.addEventListener("click", function () {

  fetch('selectInfo')
    .then((response) => response.json())
    .then((json) => {
      const baseUrl = '/detailInfo'
      // URL에 추가할 매개변수를 담은 객체 생성
      const queryParams = { id: json.id };
      const queryString = new URLSearchParams(queryParams).toString();
      const finalUrl = `${baseUrl}?${queryString}`;
      location.href = finalUrl
    })

})



addEventListener("load", inUse)

var count = 0;
function inUse() {
  fetch('alluserInfo')
    .then((response) => response.json())
    .then((json) => {
      json.forEach((jsons, index, arr) => {
        if (jsons.seats.length !== 0) {
          for (var value of arr[index].seats) {
            textChange(value)
          }
        }
      })
    })
}

function textChange(value) {
  if (value !== "N") {
    document.getElementById(`${value}`).innerText = "사용중"

    console.log((document.getElementById(`${value}`).innerText))
    count++;
    document.getElementById('number').innerText = count
  }
}




// 새로운 모달 창의 x를 누르면 모달 창이 사라진다.
const closeNewModalBtn = newModal.querySelector(".close-area");
closeNewModalBtn.addEventListener("click", evt => {
  newModal.style.display = "none";
  // 새로운 모달의 내용 초기화 등 추가 작업 가능
});


// 새로운 모달 창의 바깥 영역을 클릭하면 꺼지게 한다.
newModal.addEventListener("click", e => {
  const evTarget = e.target;
  if (evTarget.classList.contains("modal-overlay")) {
    newModal.style.display = "none";
    // 새로운 모달의 내용 초기화 등 추가 작업 가능
  }


});

// esc 버튼을 누르면 새로운 모달 창 닫기
window.addEventListener("keyup", e => {
  if (newModal.style.display == "flex" && e.key == "Escape") {
    newModal.style.display = "none";
    // 새로운 모달의 내용 초기화 등 추가 작업 가능
  }
});


const $nav = document.querySelector('#tab-button-nav')
const $sections = document.querySelectorAll('.tab-section');

$nav.addEventListener('click', (e) => {
  if (!e.target.classList.contains('tab')) {
    return;
  }

  const focusedTabId = e.target.dataset.tabSection;

  $sections.forEach(($section) => {
    if ($section.id === focusedTabId) {
      $section.removeAttribute('hidden');
    } else {
      $section.setAttribute('hidden', true);
    }
  });
});

"use strict"

const seatChangebutton = document.getElementById("seatChange")
const forcedDeparture = document.getElementById("forcedDeparture")
const timeChange = document.getElementById("timeChange")

const name = document.getElementById("name")
const validity = document.getElementById("validity")
const validityAddbutton = document.getElementById("validityAdd")
const validityDiffbutton = document.getElementById("validityDiff")
const days = document.getElementById("days")
const hours = document.getElementById("hours")

const minutes = document.getElementById("minutes")
const timeAddbutton = document.getElementById("timeAdd")
const timeDiffbutton = document.getElementById("timeDiff")

// 쿼리 스트링에서 id 값을 가져오기
const queryStringsearch = window.location.search;
const urlParams = new URLSearchParams(queryStringsearch);
const targetUserId = urlParams.get('id');


dynamicTable.addEventListener('click', function (event) {

	if (event.target.tagName === 'TD') {

		const prevSelectedRow = document.querySelector('.selected');
		if (prevSelectedRow) {
			prevSelectedRow.classList.remove('selected');
		}
		const selectedRow = event.target.parentNode;
		selectedRow.classList.add('selected');
	}
}

)

seatChangebutton.addEventListener("click", function () {
	const selectedRow = document.querySelector('.selected');
	if (selectedRow) {
		const cells = selectedRow.cells
		const req = {
			changeProduct: cells[0].textContent,
			changeSeats: cells[1].textContent,
			changeTime: cells[2].textContent,
		}


		fetch("/detailInfo", {
			method: "POST",
			//get, post, put, delete, 조회, 생성, 수정, 삭제
			headers: {
				"Content-Type": "application/json"
			},
			body: JSON.stringify(req)
		}

		)

			.then((res) => res.json())
			.then((res) => {

				if (res.success) {
					location.href = "/adminseatschange"
				}

			})
			.catch((err) => {
				console.error("좌석 변경 중 오류 발생")
			})


	}
})

forcedDeparture.addEventListener("click", function () {
	const selectedRow = document.querySelector('.selected');
	if (selectedRow) {
		const cells = selectedRow.cells
		const req = {
			deleteProduct: cells[0].textContent,
			deleteSeats: cells[1].textContent,
			deleteTime: cells[2].textContent,
		}


		fetch("/detailInfo", {
			method: "POST",
			//get, post, put, delete, 조회, 생성, 수정, 삭제
			headers: {
				"Content-Type": "application/json"
			},
			body: JSON.stringify(req)
		}

		)

			.then((res) => res.json())
			.then((res) => {

				if (res.success) {
					alert(res.msg)
				}
			})
			.catch((err) => {
				console.error("강제 퇴실 중 오류 발생")
			})


	}
})


timeChange.addEventListener("click", function () {
	modal.style.display = "flex";
	name.innerText = targetUserId
})

//모달창의 x를 누르면 모달창이 사라진다.  
const closeBtn = modal.querySelector(".close-area");
closeBtn.addEventListener("click", evt => {
	modal.style.display = "none";
	dynamicTable.innerHTML = ""
});

//모달창의 바깥 영역을 클릭하면 꺼지게 한다.
modal.addEventListener("click", e => {
	const evTarget = e.target;
	if (evTarget.classList.contains("modal-overlay")) {
		modal.style.display = "none";
	}
});

// esc 버튼을 누르면 모달창 닫기
window.addEventListener("keyup", e => {
	if (modal.style.display == "flex" && e.key == "Escape") {
		modal.style.display = "none";
	}
}
);

validityAddbutton.addEventListener("click", function () {
	const req = {
		addValidity: validity.value
	}

	fetch("/detailInfo", {
		method: "POST",
		//get, post, put, delete, 조회, 생성, 수정, 삭제
		headers: {
			"Content-Type": "application/json"
		},
		body: JSON.stringify(req)
	}

	)

		.then((res) => res.json())
		.then((res) => {

			if (res.success) {
				alert(res.msg)
			}
		})
		.catch((err) => {
			console.error("유효 기간 추가 중 오류 발생")
		})
})


validityDiffbutton.addEventListener("click", function () {
	const req = {
		diffValidity: validity.value
	}

	fetch("/detailInfo", {
		method: "POST",
		//get, post, put, delete, 조회, 생성, 수정, 삭제
		headers: {
			"Content-Type": "application/json"
		},
		body: JSON.stringify(req)
	}

	)

		.then((res) => res.json())
		.then((res) => {

			if (res.success) {
				alert(res.msg)
			}
		})
		.catch((err) => {
			console.error("유효 기간 차감 중 오류 발생")
		})
})



timeAddbutton.addEventListener("click", function () {
	const req = {
		addDays: days.value,
		addHours: hours.value,
		addMinutes: minutes.value
	}

	fetch("/detailInfo", {
		method: "POST",
		//get, post, put, delete, 조회, 생성, 수정, 삭제
		headers: {
			"Content-Type": "application/json"
		},
		body: JSON.stringify(req)
	}

	)

		.then((res) => res.json())
		.then((res) => {

			if (res.success) {
				alert(res.msg)
			}
		})
		.catch((err) => {
			console.error("시간 추가 중 오류 발생")
		})
})

timeDiffbutton.addEventListener("click", function () {
	const req = {
		diffDays: days.value,
		diffHours: hours.value,
		diffMinutes: minutes.value
	}

	fetch("/detailInfo", {
		method: "POST",
		//get, post, put, delete, 조회, 생성, 수정, 삭제
		headers: {
			"Content-Type": "application/json"
		},
		body: JSON.stringify(req)
	}

	)

		.then((res) => res.json())
		.then((res) => {

			if (res.success) {
				alert(res.msg)
			}
		})
		.catch((err) => {
			console.error("시간 차감 중 오류 발생")
		})
})




addEventListener("load", selectInfo)

function selectInfo() {
	fetch('alluserinfo')
		.then((response) => response.json())
		.then((json) => {

			json.forEach((jsons, index, arr) => {
				if (jsons.id === targetUserId) {
					const targetUser = arr[index];
					for (let i = 0; i < targetUser.product.length; i++) {

						const row = dynamicTable.insertRow();

						const cell1 = row.insertCell(0);
						cell1.appendChild(document.createTextNode(targetUser.product[i]));

						const cell2 = row.insertCell(1);
						cell2.appendChild(document.createTextNode(targetUser.seats[i]));

						const cell3 = row.insertCell(2);
						cell3.appendChild(document.createTextNode(targetUser.remainedTime[i]));

					}
				}
			})
		})


}


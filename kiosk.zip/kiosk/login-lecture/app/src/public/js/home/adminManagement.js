"use strict";


const adminvalidity = document.querySelector("#adminvalidity")
const search = document.querySelector("#search")
const selectPage = document.querySelectorAll('.page1')
const searchPage = document.querySelectorAll('.page2')
const nextButton = document.getElementById("nextbutton")
const previousButton = document.getElementById("previousbutton")
const searchButton = document.getElementById("searchbutton")
const ticket = document.querySelector('.ticket')
const giveButton = document.getElementById("give")
const dynamicTable = document.querySelector("#dynamicTable")
const giveComplete = document.querySelector("#giveComplete")

const ticketkind = document.querySelector("#ticketkind")
const productkind = document.querySelector("#productkind")
const timekind = document.querySelector("#timekind")

const selectedticket = document.querySelector("select[class=ticket] option:checked").innerText;
const selectedProduct = document.querySelector("select[class=product] option:checked").innerText;
const selectedTime = document.querySelector("select[class=time] option:checked").innerText;

ticket.addEventListener('change', function () {
  var product = document.querySelector('.product');

  var ticketOption = ticket.options[ticket.selectedIndex].value;

  var productOptions = {
    seats: ["일일권", "충전권", "기간권", "고정석"],
    lockers: ["Room type-1day", "Room type-2day", "Room type-3day", "Room type-4day"]
  };

  function caseInswitch(ticketOption) {
    var productOption = "";
    switch (ticketOption) {
      case "좌석":
        productOption = productOptions.seats;
        break;
      case "사물함":
        productOption = productOptions.lockers;
        break;
    }
    return productOption;
  }

  // 기존 options 변수를 제거하고, 각 option을 새로 생성하여 추가
  product.innerHTML = ''; // 기존 내용 초기화

  for (var i = 0; i < caseInswitch(ticketOption).length; i++) {
    var option = document.createElement('option');
    option.text = caseInswitch(ticketOption)[i];
    product.append(option);
  }
})


previousButton.addEventListener("click", function () {
  searchPage.forEach(element => {
    element.setAttribute("hidden", true)
  })

  selectPage.forEach(element => {
    element.removeAttribute("hidden")
  })

})



//모달창의 x를 누르면 모달창이 사라진다.
const closeBtn = modal.querySelector(".close-area");
closeBtn.addEventListener("click", evt => {
  modal.style.display = "none";
});

//모달창의 바깥 영역을 클릭하면 꺼지게 한다.
modal.addEventListener("click", e => {
  const evTarget = e.target;
  if (evTarget.classList.contains("modal-overlay")) {
    modal.style.display = "none";
  }
});

// esc 버튼을 누르면 모달창 닫기
window.addEventListener("keyup", e => {
  if (modal.style.display == "flex" && e.key == "Escape") {
    modal.style.display = "none";
  }
}
);



nextButton.addEventListener("click", function () {
  searchPage.forEach(element => {
    element.removeAttribute('hidden');
  });

  selectPage.forEach(element => {
    element.setAttribute('hidden', true);
  });

}
)

searchButton.addEventListener("click", fetchInfo)

function fetchInfo() {
  fetch('alluserinfo')
    .then((response) => response.json())
    .then((json) => {

      dynamicTable.innerHTML = '';

      let thead = document.createElement('thead');
      dynamicTable.appendChild(thead)

      let row_1 = document.createElement('tr');
      let heading_1 = document.createElement('th');
      heading_1.innerHTML = '이름';
      let heading_2 = document.createElement('th');
      heading_2.innerHTML = '전화번호';
      let heading_3 = document.createElement('th');
      heading_3.innerHTML = '유효기간';
      let heading_4 = document.createElement('th');

      var button = document.createElement('input');
      button.type = 'button';
      button.id = 'give';
      button.value = '지급'

      heading_4.appendChild(button)
      row_1.appendChild(heading_1);
      row_1.appendChild(heading_2);
      row_1.appendChild(heading_3);
      row_1.appendChild(heading_4);
      thead.appendChild(row_1)

      const filtered = json.filter(jsons => jsons.id.includes(search.value) || jsons.phone.includes(search.value))
      displayData(filtered)


      give.addEventListener("click", e => {


        modal.style.display = "flex";


        ticketkind.innerHTML = selectedticket
        productkind.innerHTML = selectedProduct
        timekind.innerHTML = selectedTime
      });

    })

}

giveComplete.addEventListener("click", function () {
  const selectedRow = document.querySelector('.selected');
  const cells = selectedRow.cells

  const req = {
    id: cells[0].textContent,
    product: selectedProduct,
    time: selectedTime,
    price: 0,
    validity: adminvalidity.value,
  }

  console.log(req)

  fetch("/adminManagement", {
    method: "POST",
    //get, post, put, delete, 조회, 생성, 수정, 삭제
    headers: {
      "Content-Type": "application/json"
    },
    //clients가 전달받고자 하는 데이터 형태
    body: JSON.stringify(req)
  })

    .then((res) => res.json())
    .then((res) => {


      if (res.success) {
        alert(res.msg)
      }
    })
    .catch((err) => {
      console.error("리스트 저장 중 오류 발생")
    });

})



function displayData(filtered) {

  for (let i = 0; i < filtered.length; i++) {

    const row = dynamicTable.insertRow();

    const cell1 = row.insertCell(0);
    cell1.appendChild(document.createTextNode(filtered[i].id));

    const cell2 = row.insertCell(1);
    cell2.appendChild(document.createTextNode(filtered[i].phone));


  }
}

dynamicTable.addEventListener('click', function (event) {

  if (event.target.tagName === 'TD') {

    const prevSelectedRow = document.querySelector('.selected');
    if (prevSelectedRow) {
      prevSelectedRow.classList.remove('selected');
    }
    const selectedRow = event.target.parentNode;
    selectedRow.classList.add('selected');
  }
}


)



const $nav = document.querySelector('#tab-button-nav')
const $sections = document.querySelectorAll('.tab-section');

$nav.addEventListener('click', (e) => {
  if (!e.target.classList.contains('tab')) {
    return;
  }

  const focusedTabId = e.target.dataset.tabSection;

  $sections.forEach(($section) => {
    if ($section.id === focusedTabId) {
      $section.removeAttribute('hidden');
    } else {
      $section.setAttribute('hidden', true);
    }
  });
})



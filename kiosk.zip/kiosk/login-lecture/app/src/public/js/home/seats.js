"use strict";


const buttonRow = document.querySelector(".button-row")

buttonRow.addEventListener("click", function (e) {
  console.log(buttonRow)
  btnChange(e.target.dataset.set)
  console.log(e.target.dataset.set)
})



function btnChange(event) {

  const req = {
    "seats": event
  }


  fetch("/seats", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(req)
  })
    .then((res) => res.json())
    .then((res) => {

      alert(res.msg)
    })

}


addEventListener("load", inUse)

function inUse() {
  fetch('alluserInfo')
    .then((response) => response.json())
    .then((json) => {
      json.forEach((jsons, index, arr) => {
        if (jsons.seats.length !== 0) {
          for (var value of arr[index].seats) {
            textChange(value)
          }
        }
      })
    })
}

function textChange(value) {
  if (value !== "N") {
    document.getElementById(`${value}`).innerText = "사용중"
  }
}










"use strict"

/**고정석 탭 부분 */
const fixedProduct = document.getElementById("fixedProduct")
const fixedPrice = document.getElementById("fixedPrice")
const fixedTime = document.getElementById("fixedTime")
const fixedValidity = document.getElementById("fixedValidity")
const fixedRegister = document.getElementById("fixedRegister")
const fixedTable = document.getElementById("fixedTable")
const fixedDelete = document.getElementById("fixedDelete")
const fixedCorrection = document.getElementById("fixedCorrection")

/**충전권 탭 부분 */
const chargedProduct = document.getElementById("chargedProduct")
const chargedPrice = document.getElementById("chargedPrice")
const chargedTime = document.getElementById("chargedTime")
const chargedValidity = document.getElementById("chargedValidity")
const chargedRegister = document.getElementById("chargedRegister")
const chargedTable = document.getElementById("chargedTable")
const chargedDelete = document.getElementById("chargedDelete")
const chargedCorrection = document.getElementById("chargedCorrection")


/**기간제 탭 부분 */
const termProduct = document.getElementById("termProduct")
const termPrice = document.getElementById("termPrice")
const termTime = document.getElementById("termTime")
const termValidity = document.getElementById("termValidity")
const termRegister = document.getElementById("termRegister")
const termTable = document.getElementById("termTable")
const termDelete = document.getElementById("termDelete")
const termCorrection = document.getElementById("termCorrection")



const modal = document.getElementById("modal");
const modalContent = document.getElementById("modalContent");
const correctionComplete = document.getElementById("correctionComplete")

const changeProduct = document.getElementById("changeProduct")
const changePrice = document.getElementById("changePrice")
const changeTime = document.getElementById("changeTime")
const changeValidity = document.getElementById("changeValidity")

/**고정권 탭 부분 */
fixedTable.addEventListener('click', function(event) {

  if (event.target.tagName === 'TD') {

    const prevSelectedRow = document.querySelector('.selected');
    if (prevSelectedRow) {
      prevSelectedRow.classList.remove('selected');
    }
    const selectedRow = event.target.parentNode;
    selectedRow.classList.add('selected');
  }}
  
  )

  fixedDelete.addEventListener("click", function(){
    /**fixedTable에서 .selected를 찾아야합니다....  */
  const selectedRow = document.querySelector('.selected');
  if (selectedRow){
      const cells = selectedRow.cells
      const req = {
        deleteProduct : cells[0].textContent,
        deletePrice : cells[1].textContent,
        deleteTime : cells[2].textContent,
        deleteValidity : cells[3].textContent
      }
      

  fetch("/adminkioce", {
    method : "POST",
    //get, post, put, delete, 조회, 생성, 수정, 삭제
    headers : {
        "Content-Type" : "application/json"
    },
    body : JSON.stringify(req)
  }

  )

  .then((res) => res.json())
  .then((res) => {

  if (res.success) {
  alert(res.msg) 
  }
    })
  .catch((err) => {
    console.error("리스트 삭제 중 오류 발생")
    })

    
  }


})


fixedRegister.addEventListener("click", makeFixedProduct)

function makeFixedProduct(){

  const row = fixedTable.insertRow();

  const cell1 = row.insertCell(0);
  cell1.appendChild(document.createTextNode(fixedProduct.value));

  const cell2 = row.insertCell(1);
  cell2.appendChild(document.createTextNode(fixedPrice.value));

  const cell3 = row.insertCell(2);
  cell3.appendChild(document.createTextNode(fixedTime.value));

  const cell4 = row.insertCell(3);
  cell4.appendChild(document.createTextNode(fixedValidity.value));


// 전역변수는 전체 스크립트에서 항상 동일한 값으로 유지. 
// 따라서 개수도 동일 & 
// 전역 변수로 선언된 button이 한 번 생성된 후에는 
// 해당 변수가 이미 생성된 버튼을 가리키게 되어 
// 계속해서 같은 버튼을 참조하게 됩니다.

const req = {
  addProduct : fixedProduct.value,
  addPrice : fixedPrice.value,
  addTime : fixedTime.value,
  addValidity : fixedValidity.value
}


fetch("/adminkioce", {
  method : "POST",
  //get, post, put, delete, 조회, 생성, 수정, 삭제
  headers : {
      "Content-Type" : "application/json"
  },
  //clients가 전달받고자 하는 데이터 형태
  body : JSON.stringify(req)
})

.then((res) => res.json())
.then((res) => {


if (res.success) {
  alert(res.msg) 
}
})
.catch((err) => {
  console.error("리스트 저장 중 오류 발생")
});

}


/**충전권 탭 부분 */

chargedTable.addEventListener('click', function(event) {

  if (event.target.tagName === 'TD') {

    const prevSelectedRow = document.querySelector('.selected');
    if (prevSelectedRow) {
      prevSelectedRow.classList.remove('selected');
    }
    const selectedRow = event.target.parentNode;
    selectedRow.classList.add('selected');
  }}
  
  )

  chargedDelete.addEventListener("click", function(){
  const selectedRow = document.querySelector('.selected');
  if (selectedRow){
      const cells = selectedRow.cells
      const req = {
        deleteProduct : cells[0].textContent,
        deletePrice : cells[1].textContent,
        deleteTime : cells[2].textContent,
        deleteValidity : cells[3].textContent
      }
      

  fetch("/adminkioce", {
    method : "POST",
    //get, post, put, delete, 조회, 생성, 수정, 삭제
    headers : {
        "Content-Type" : "application/json"
    },
    body : JSON.stringify(req)
  }

  )

  .then((res) => res.json())
  .then((res) => {

  if (res.success) {
  alert(res.msg) 
  }
    })
  .catch((err) => {
    console.error("리스트 삭제 중 오류 발생")
    })

    
  }


})


chargedRegister.addEventListener("click", makeChargedProduct)

function makeChargedProduct(){

  const row = chargedTable.insertRow();

  const cell1 = row.insertCell(0);
  cell1.appendChild(document.createTextNode(chargedProduct.value));

  const cell2 = row.insertCell(1);
  cell2.appendChild(document.createTextNode(chargedPrice.value));

  const cell3 = row.insertCell(2);
  cell3.appendChild(document.createTextNode(chargedTime.value));

  const cell4 = row.insertCell(3);
  cell4.appendChild(document.createTextNode(chargedValidity.value));


// 전역변수는 전체 스크립트에서 항상 동일한 값으로 유지. 
// 따라서 개수도 동일 & 
// 전역 변수로 선언된 button이 한 번 생성된 후에는 
// 해당 변수가 이미 생성된 버튼을 가리키게 되어 
// 계속해서 같은 버튼을 참조하게 됩니다.

const req = {
  addProduct : chargedProduct.value,
  addPrice : chargedPrice.value,
  addTime : chargedTime.value,
  addValidity : chargedValidity.value
}


fetch("/adminkioce", {
  method : "POST",
  //get, post, put, delete, 조회, 생성, 수정, 삭제
  headers : {
      "Content-Type" : "application/json"
  },
  //clients가 전달받고자 하는 데이터 형태
  body : JSON.stringify(req)
})

.then((res) => res.json())
.then((res) => {


if (res.success) {
  alert(res.msg) 
}
})
.catch((err) => {
  console.error("리스트 저장 중 오류 발생")
});

}

/**기간제 탭 부분 */

termTable.addEventListener('click', function(event) {

  if (event.target.tagName === 'TD') {

    const prevSelectedRow = document.querySelector('.selected');
    if (prevSelectedRow) {
      prevSelectedRow.classList.remove('selected');
    }
    const selectedRow = event.target.parentNode;
    selectedRow.classList.add('selected');
  }}
  
  )

  termDelete.addEventListener("click", function(){
  const selectedRow = document.querySelector('.selected');
  if (selectedRow){
      const cells = selectedRow.cells
      const req = {
        deleteProduct : cells[0].textContent,
        deletePrice : cells[1].textContent,
        deleteTime : cells[2].textContent,
        deleteValidity : cells[3].textContent
      }
      

  fetch("/adminkioce", {
    method : "POST",
    //get, post, put, delete, 조회, 생성, 수정, 삭제
    headers : {
        "Content-Type" : "application/json"
    },
    body : JSON.stringify(req)
  }

  )

  .then((res) => res.json())
  .then((res) => {

  if (res.success) {
  alert(res.msg) 
  }
    })
  .catch((err) => {
    console.error("리스트 삭제 중 오류 발생")
    })

    
  }


})


termRegister.addEventListener("click", makeTermProduct)

function makeTermProduct(){

  const row = termTable.insertRow();

  const cell1 = row.insertCell(0);
  cell1.appendChild(document.createTextNode(termProduct.value));

  const cell2 = row.insertCell(1);
  cell2.appendChild(document.createTextNode(termPrice.value));

  const cell3 = row.insertCell(2);
  cell3.appendChild(document.createTextNode(termTime.value));

  const cell4 = row.insertCell(3);
  cell4.appendChild(document.createTextNode(termValidity.value));


// 전역변수는 전체 스크립트에서 항상 동일한 값으로 유지. 
// 따라서 개수도 동일 & 
// 전역 변수로 선언된 button이 한 번 생성된 후에는 
// 해당 변수가 이미 생성된 버튼을 가리키게 되어 
// 계속해서 같은 버튼을 참조하게 됩니다.

const req = {
  addProduct : termProduct.value,
  addPrice : termPrice.value,
  addTime : termTime.value,
  addValidity : termValidity.value
}


fetch("/adminkioce", {
  method : "POST",
  //get, post, put, delete, 조회, 생성, 수정, 삭제
  headers : {
      "Content-Type" : "application/json"
  },
  //clients가 전달받고자 하는 데이터 형태
  body : JSON.stringify(req)
})

.then((res) => res.json())
.then((res) => {


if (res.success) {
  alert(res.msg) 
}
})
.catch((err) => {
  console.error("리스트 저장 중 오류 발생")
});

}

addEventListener("load", fetchPage)

/**각 상품명의 앞 세글자로 어떤 상품이 어떤 탭에 들어가야 되는지를 나눈 것. */

function fetchPage() {
  fetch('productInfopage')
        .then((response) => response.json())
        .then((json) => { 

          const fixedData = json.filter((arrs) => arrs.product.substring(0, 3) == "고정석");
          const chargedData = json.filter((arrs) => arrs.product.substring(0, 3) == "충전권");
          const termData = json.filter((arrs) => arrs.product.substring(0, 3) == "기간제");

          fixedDisplay(fixedData)
          chargedDisplay(chargedData)
          termDisplay(termData)

          })
        
        
        }
          
/**고정석 탭 부분 리로드시 보여주기 */
function fixedDisplay(json){

  for(let i = 0; i < json.length; i++){

  const row = fixedTable.insertRow();

  const cell1 = row.insertCell(0);
  cell1.appendChild(document.createTextNode(json[i].product));

  const cell2 = row.insertCell(1);
  cell2.appendChild(document.createTextNode(json[i].price));

  const cell3 = row.insertCell(2);
  cell3.appendChild(document.createTextNode(json[i].time));

  const cell4 = row.insertCell(3);
  cell4.appendChild(document.createTextNode(json[i].validity));

  }
}

/**충전권 탭 부분 리로드시 보여주기 */

function chargedDisplay(json){

  for(let i = 0; i < json.length; i++){

  const row = chargedTable.insertRow();

  const cell1 = row.insertCell(0);
  cell1.appendChild(document.createTextNode(json[i].product));

  const cell2 = row.insertCell(1);
  cell2.appendChild(document.createTextNode(json[i].price));

  const cell3 = row.insertCell(2);
  cell3.appendChild(document.createTextNode(json[i].time));

  const cell4 = row.insertCell(3);
  cell4.appendChild(document.createTextNode(json[i].validity));

  }
}
/**기간제 탭 부분 리로드시 보여주기 */

function termDisplay(json){

  for(let i = 0; i < json.length; i++){

  const row = termTable.insertRow();

  const cell1 = row.insertCell(0);
  cell1.appendChild(document.createTextNode(json[i].product));

  const cell2 = row.insertCell(1);
  cell2.appendChild(document.createTextNode(json[i].price));

  const cell3 = row.insertCell(2);
  cell3.appendChild(document.createTextNode(json[i].time));

  const cell4 = row.insertCell(3);
  cell4.appendChild(document.createTextNode(json[i].validity));

  }
}



const $nav = document.querySelector('#tab-button-nav')
const $sections = document.querySelectorAll('.tab-section');

$nav.addEventListener('click', (e) => {
  if (!e.target.classList.contains('tab')) {
    return;
  }
  
  const focusedTabId = e.target.dataset.tabSection;

  $sections.forEach(($section) => {
    if ($section.id === focusedTabId) {
      $section.removeAttribute('hidden');
    } else {
      $section.setAttribute('hidden', true);
    }
  });
});

/**모달창은 여러개 만들 필요가 없다.. */

correctionComplete.addEventListener("click", ()=>{
  
  const selectedRow = document.querySelector('.selected');
  if (selectedRow){
    const cells = selectedRow.cells
    const req = {
      /** 이렇게 수정하겠다는 것을 서버로 던진다. */
      changeProduct : changeProduct.value,
      changePrice : changePrice.value,
      changeTime : changeTime.value,
      changeValidity : changeValidity.value,

      /**수정 대상 항목도 서버로 던진다.  */
      originProduct : cells[0].textContent,
      originPrice : cells[1].textContent,
      originTime : cells[2].textContent,
      originValidity : cells[3].textContent
    }

    fetch("/adminkioce", {
      method : "POST",
      //get, post, put, delete, 조회, 생성, 수정, 삭제
      headers : {
          "Content-Type" : "application/json"
      },
      body : JSON.stringify(req)
    }
  
    )
  
    .then((res) => res.json())
    .then((res) => {
  
    if (res.success) {
    alert(res.msg) 
    }
      })
    .catch((err) => {
      console.error("리스트 수정 중 오류 발생")
      })
  }
  
 

 
  

})


fixedCorrection.addEventListener("click", e =>{
    modal.style.display = "flex";
});
chargedCorrection.addEventListener("click", e =>{
  modal.style.display = "flex";
});
termCorrection.addEventListener("click", e =>{
  modal.style.display = "flex";
});


 //모달창의 x를 누르면 모달창이 사라진다.
 const closeBtn = modal.querySelector(".close-area");
 closeBtn.addEventListener("click", evt => {
     modal.style.display = "none";
 });

 //모달창의 바깥 영역을 클릭하면 꺼지게 한다.
 modal.addEventListener("click", e=>{
    const evTarget = e.target;
    if(evTarget.classList.contains("modal-overlay")){
        modal.style.display="none";
    }
 });

 // esc 버튼을 누르면 모달창 닫기
 window.addEventListener("keyup", e=>{
    if(modal.style.display == "flex" && e.key=="Escape"){
        modal.style.display="none";
    }
 }
 );

 





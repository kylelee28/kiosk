"use strict"

const dynamicTable = document.getElementById("dynamicTable")
const choice = document.getElementById("choice")



addEventListener("load", fetchPage)

function fetchPage() {
  fetch('kioceInfopage')
        .then((response) => response.json())
        .then((json) => { 
        displayData(json)
          })
        }
          
function displayData(json){

  for(let i = 0; i < json.length; i++){

    var button = document.createElement('input');
    button.type = 'button';
    button.id = 'choice';
    button.value = '선택'; 

  const row = dynamicTable.insertRow();

  const cell1 = row.insertCell(0);
  cell1.appendChild(document.createTextNode(json[i].product));

  const cell2 = row.insertCell(1);
  cell2.appendChild(document.createTextNode(json[i].price));

  const cell3 = row.insertCell(2);
  cell3.appendChild(document.createTextNode(json[i].time));

  const cell4 = row.insertCell(3);
  cell4.appendChild(document.createTextNode(json[i].validity));

  const cell5 = row.insertCell(4);
  cell5.appendChild(button);
 
  button.addEventListener("click", buttonChoice)
  }

}
        
function buttonChoice(){
  var closestTR = this.closest('tr');

  var cell1Value = closestTR.cells[0].textContent;
  var cell2Value = closestTR.cells[1].textContent;
  var cell3Value = closestTR.cells[2].textContent;
  var cell4Value = closestTR.cells[3].textContent;

  const req = {
    product : cell1Value,
    price : cell2Value,
    time : cell3Value,
    validity : cell4Value
  }
  
  fetch("/kioce", {
    method : "POST",
    headers : {
        "Content-Type" : "application/json"
    },
    body : JSON.stringify(req)
  })
  .then((res) => res.json())
  .then((res) => {
    if (res.success) {
      location.href = "/seats"
      alert(res.msg) 
    }
    })
    .catch((err) => {
      console.error("데이터 선택 오류 발생")
    });

}





const $nav = document.querySelector('#tab-button-nav')
const $sections = document.querySelectorAll('.tab-section');

$nav.addEventListener('click', (e) => {
  if (!e.target.classList.contains('tab')) {
    return;
  }
  
  const focusedTabId = e.target.dataset.tabSection;

  $sections.forEach(($section) => {
    if ($section.id === focusedTabId) {
      $section.removeAttribute('hidden');
    } else {
      $section.setAttribute('hidden', true);
    }
  });
});


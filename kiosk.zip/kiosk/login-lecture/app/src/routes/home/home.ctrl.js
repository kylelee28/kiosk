"use strict"

const User = require("../../models/User")
const UserStorage = require("../../models/UserStorage")
const { dataSplit } = require("../../models/UserStorage")
const { controlArray } = require("../../models/UserStorage")

const fs = require("fs").promises

async function selectInfo() {
    const selectInfo = JSON.parse(await fs.readFile("./src/databases/seatsSelect.json"))
    return selectInfo
}

async function productInfo() {
    const productInfo = JSON.parse(await fs.readFile("./src/databases/productDisplay.json"))
    return productInfo
}

async function alluserinfo() {
    const alluserinfo = JSON.parse(await fs.readFile("./src/databases/alluser.json"))
    return alluserinfo
}

async function coveredInfo() {
    const coveredInfo = JSON.parse(await fs.readFile("./src/databases/user.json"))
    return coveredInfo
}

async function typeInfo() {
    const coveredInfo = JSON.parse(await fs.readFile("./src/databases/seatsType.json"))
    return coveredInfo
}

const output = {
    typeInfo: async (req, res) => {
        const result = await typeInfo()
        res.send(result)
    },

    productInfopage: async (req, res) => {
        const result = await productInfo()
        res.send(result)
    },
    alluserinfo: async (req, res) => {
        const result = await alluserinfo()
        res.send(result)
    },
    coveredInfo: async (req, res) => {
        const result = await coveredInfo()
        res.send(result)
    },

    selectInfo: async (req, res) => {
        const result = await selectInfo()
        res.send(result)
    },

    adminkioce: (req, res) => {
        res.render("home/adminkioce")
    },
    kioce: (req, res) => {
        res.render("home/kioce")
    },

    hello: (req, res) => {
        res.render("home/index")
    },
    initialPage: (req, res) => {
        res.render("home/initialPage")
    },

    register: (req, res) => {
        res.render("home/register")
    },
    seats: (req, res) => {
        res.render("home/seats")
    },
    days: (req, res) => {
        res.render("home/days")
    },
    admininfo: (req, res) => {
        res.render("home/admininfo")
    },
    adminManagement: (req, res) => {
        res.render("home/adminManagement")
    },

    kioceInfo: (req, res) => {
        res.render("home/kioceInfo")
    },

    adminseats: (req, res) => {
        res.render("home/adminseats")
    },
    adminseatschange: (req, res) => {
        res.render("home/adminseatschange")
    },
    detailInfo: (req, res) => {
        res.render("home/detailInfo")
    },
    adminInfo: (req, res) => {
        res.render("home/adminInfo")
    },
}

const process = {

    initialPage: async (req, res) => {
        const user = new User(req.body)
        if (req.body.loginId) {
            await UserStorage.timeRenewal()
            await UserStorage.timeCheck()
            const response = await user.login()
            await UserStorage.coveredProduct(req.body)
            return res.json(response)
        }
        if (req.body.logoutId) {
            const response = await user.logout()
            return res.json(response)
        }
        if (req.body.checkProduct) {
            const response = await UserStorage.logoutTime(req.body)
            return res.json(response)
        }
    },

    register: async (req, res) => {
        const user = new User(req.body)
        const response = await user.register()
        return res.json(response)
    },

    seats: async (req, res) => {
        const user = new User(req.body)
        const response = await user.pushSet()
        await UserStorage.loginTime()
        return res.json(response)
    },

    days: async (req, res) => {
        const user = new User(req.body)
        const response = await user.pushDays()
        return res.json(response)
    },


    adminkioce: async (req, res) => {
        const user = new User(req.body)
        const response = await user.adminControl()
        return res.json(response)
    },

    kioce: async (req, res) => {
        const user = new User(req.body)
        const response = await user.kiocedata()
        return res.json(response)
    },

    adminManagement: async (req, res) => {
        const user = new User(req.body)
        const response = await user.adminManagement()
        return res.json(response)
    },

    kioceInfo: async (req, res) => {
        const user = new User(req.body)
        const response = await user.changeTicket()
        return res.json(response)
    },


    adminseats: async (req, res) => {
        const user = new User(req.body)
        const response = await user.seatsControl()
        return res.json(response)
    },

    adminseatschange: async (req, res) => {
        const user = new User(req.body)
        const response = await user.seatsChange()
        return res.json(response)
    },


    detailInfo: async (req, res) => {
        const user = new User(req.body)
        const response = await user.detailControl()
        return res.json(response)
    },

    adminInfo: async (req, res) => {
        const user = new User(req.body)
        const response = await user.detailControl()
        return res.json(response)
    }
}
module.exports = {
    output,
    process,
}
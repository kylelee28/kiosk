"use strict"

const express = require("express")
const router = express.Router()

const ctrl = require("./home.ctrl")

router.get("/", ctrl.output.hello)

router.get("/initialPage", ctrl.output.initialPage)


router.get("/register", ctrl.output.register)
router.get("/seats", ctrl.output.seats)
router.get("/days", ctrl.output.days)

router.get("/kioce", ctrl.output.kioce)
router.get("/adminkioce", ctrl.output.adminkioce)
router.get("/productInfopage", ctrl.output.productInfopage)
router.get("/adminseats", ctrl.output.adminseats)
router.get("/detailInfo", ctrl.output.detailInfo)

router.get("/adminInfo", ctrl.output.adminInfo)



router.get("/kioceInfo", ctrl.output.kioceInfo)
router.get("/coveredInfo", ctrl.output.coveredInfo)
router.get("/adminManagement", ctrl.output.adminManagement)
router.get("/adminseatschange", ctrl.output.adminseatschange)

router.get("/alluserinfo", ctrl.output.alluserinfo)
router.get("/selectInfo", ctrl.output.selectInfo)
router.get("/typeInfo", ctrl.output.typeInfo)




router.post("/initialPage", ctrl.process.initialPage)
router.post("/register", ctrl.process.register)
router.post("/seats", ctrl.process.seats)
router.post("/days", ctrl.process.days)

router.post("/adminkioce", ctrl.process.adminkioce)
router.post("/kioce", ctrl.process.kioce)
router.post("/adminseats", ctrl.process.adminseats)

router.post("/kioceInfo", ctrl.process.kioceInfo)

router.post("/adminManagement", ctrl.process.adminManagement)
router.post("/adminseatschange", ctrl.process.adminseatschange)

router.post("/detailInfo", ctrl.process.detailInfo)
router.post("/adminInfo", ctrl.process.adminInfo)


module.exports = router

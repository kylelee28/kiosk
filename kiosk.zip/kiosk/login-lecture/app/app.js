"use strict"

const express = require("express");
const bodyParser = require("body-parser");
const app = express();

// app.set = ("views", "./views")

const home = require("./src/routes/home")

app.set("views", "./src/views")
app.set("view engine", "ejs")

app.use(express.static(`${__dirname}/src/public`));

app.use(bodyParser.json());
app.use(bodyParser.urlencoded( {extended : true }));

app.use("/", home); //use -> 미들웨어 등록 (이거를 잘 까먹음)

module.exports = app;

//app.listen 실행
//views 디렉토리 어디
//에크마스크립트
//ejs 부분은 어디로
//arrow function을 알면 할 수 있지 않을까
//ejs 내용은 어떻게 문법적으로 처리하는가?
